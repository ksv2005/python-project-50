#!/usr/bin/env python
import argparse
import json
import yaml


# generates plain difference between two json files
def generate_json_diff(file1, file2):
    result = ["{"]
    with open(file1) as f1:
        file1_data = json.load(f1)
    with open(file2) as f2:
        file2_data = json.load(f2)
    for key in sorted(file1_data):
        if key in file2_data:
            if file1_data[key] == file2_data[key]:
                result.append(f"\t{key}: {file1_data[key]}")
            else:
                result.append(f"\t- {key}: {file1_data[key]}")
                result.append(f"\t+ {key}: {file2_data[key]}")
        else:
            result.append(f"\t- {key}: {file1_data[key]}")
    for key in sorted(file2_data):
        if key not in file1_data:
            result.append(f"\t+ {key}: {file2_data[key]}")
    result.append("}")
    return "\n".join(result)


# generates plain difference between two json files
def generate_yaml_diff(file1, file2):
    result = ["{"]
    with open(file1) as f1:
        file1_data = yaml.load(f1, yaml.Loader(f1))
    with open(file2) as f2:
        file2_data = yaml.load(f2, yaml.Loader(f2))
    print(file1_data)
    for key in sorted(file1_data):
        if key in file2_data:
            if file1_data[key] == file2_data[key]:
                result.append(f"\t{key}: {file1_data[key]}")
            else:
                result.append(f"\t- {key}: {file1_data[key]}")
                result.append(f"\t+ {key}: {file2_data[key]}")
        else:
            result.append(f"\t- {key}: {file1_data[key]}")
    for key in sorted(file2_data):
        if key not in file1_data:
            result.append(f"\t+ {key}: {file2_data[key]}")
    result.append("}")
    return "\n".join(result)


def getFilesExtension(file1, file2):
    if file1.split(".")[-1] in ["yml", "yaml"] and file2.split(".")[-1] in ["yml", "yaml"]:
        return 0
    elif file1.split(".")[-1] == "json" and file2.split(".")[-1] == "json":
        return 1


def main():
    parser = argparse.ArgumentParser(prog="gendiff",
                                     description="Compares two configuration "
                                                 "files and shows a "
                                                 "difference.")
    parser.add_argument("first_file")
    parser.add_argument("second_file")
    parser.add_argument('-f', '--format',
                        help='set format of output')
    args = parser.parse_args()
    file1, file2 = args.first_file, args.second_file
    print(lambda x: x(file1, file2),
          [generate_yaml_diff, generate_json_diff][getFilesExtension(file1, file2)])


if __name__ == '__main__':
    main()
