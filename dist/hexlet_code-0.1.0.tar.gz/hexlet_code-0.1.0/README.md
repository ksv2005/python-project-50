### Hexlet tests, linter and test-coverage status:
[![Actions Status](https://github.com/ksv2005/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/ksv2005/python-project-50/actions)
<a href="https://codeclimate.com/github/ksv2005/python-project-50/maintainability"><img src="https://api.codeclimate.com/v1/badges/8c3437401c9826df2c01/maintainability" /></a>
<a href="https://codeclimate.com/github/ksv2005/python-project-50/test_coverage"><img src="https://api.codeclimate.com/v1/badges/8c3437401c9826df2c01/test_coverage" /></a>
